# Data information

## 2ACF
- Domain: B
- SARS Coronavirus Tor2

## 2VRI
- Domain: A
- Coronavirus NL63
- Human

## 3EJG
- Domain: A
- Coronavirus 229E
- Human

## 3JZT
- Domain: D
- Feline infectious peritonitis virus (strain 79-1146) (FCoV)
- Feline

## 5HOL
- Domain: A
- Middle East respiratory syndrome-related coronavirus (MERS-CoV)
- Human

## 6MEA
- Domain: B
- Tylonycteris bat coronavirus HKU4
- Bat

## 6W02
- Domain: B
- Severe acute respiratory syndrome coronavirus 2 (SARS-CoV)
- Human

